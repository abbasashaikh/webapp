let db;
let chart;

// Initialize SQLite Database
async function initDB() {
    const SQL = await initSqlJs({ locateFile: () => 'https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/dist/sql-wasm.wasm' });
    db = new SQL.Database();
    db.run(`
        CREATE TABLE IF NOT EXISTS invoices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item TEXT,
            amount REAL,
            creditor TEXT,
            date TEXT
        );
        CREATE TABLE IF NOT EXISTS inventory (
            item TEXT PRIMARY KEY,
            stock INTEGER,
            price REAL
        );
    `);
    // Seed initial inventory if empty
    const inventoryCount = db.exec("SELECT COUNT(*) as count FROM inventory")[0].values[0][0];
    if (inventoryCount === 0) {
        db.run("INSERT INTO inventory (item, stock, price) VALUES ('Laptop', 10, 50000), ('Phone', 20, 20000)");
    }
}

// Add Invoice
document.getElementById('invoiceForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const item = document.getElementById('item').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const creditor = document.getElementById('creditor').value || 'N/A';
    const date = new Date().toISOString();

    db.run("INSERT INTO invoices (item, amount, creditor, date) VALUES (?, ?, ?, ?)", [item, amount, creditor, date]);

    // Update Inventory
    const stock = db.exec("SELECT stock FROM inventory WHERE item = ?", [item]);
    if (stock.length && stock[0].values[0][0] > 0) {
        db.run("UPDATE inventory SET stock = stock - 1 WHERE item = ?", [item]);
    } else if (!stock.length) {
        db.run("INSERT INTO inventory (item, stock, price) VALUES (?, ?, ?)", [item, 5, amount]);
    }

    updateTables();
    checkReminders();
    e.target.reset();
});

// Update Tables
function updateTables() {
    // Invoice Table
    const invoiceTbody = document.querySelector('#invoiceTable tbody');
    invoiceTbody.innerHTML = '';
    const invoices = db.exec("SELECT * FROM invoices");
    if (invoices.length) {
        invoices[0].values.forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${row[0]}</td><td>${row[1]}</td><td>${row[2]}</td><td>${row[3]}</td><td>${row[4]}</td>`;
            invoiceTbody.appendChild(tr);
        });
    }

    // Inventory Table
    const inventoryTbody = document.querySelector('#inventoryTable tbody');
    inventoryTbody.innerHTML = '';
    const inventory = db.exec("SELECT * FROM inventory");
    if (inventory.length) {
        inventory[0].values.forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${row[0]}</td><td>${row[1]}</td><td>${row[2]}</td>`;
            inventoryTbody.appendChild(tr);
        });
    }
}

// Payment Collection
document.getElementById('payButton').addEventListener('click', () => {
    const totalAmount = db.exec("SELECT SUM(amount) FROM invoices")[0].values[0][0] || 0;
    const options = {
        key: 'YOUR_RAZORPAY_KEY', // Replace with your Razorpay key
        amount: totalAmount * 100, // Convert to paise
        currency: 'INR',
        name: 'Inventory Hub',
        handler: (response) => {
            alert('Payment Successful: ' + response.razorpay_payment_id);
        },
        prefill: { contact: '1234567890', email: 'user@example.com' },
        method: { upi: true }
    };
    const rzp = new Razorpay(options);
    rzp.open();

    // Generate QR Code
    QRCode.toCanvas(document.getElementById('qrCode'), `upi://pay?pa=your-upi-id@upi&pn=InventoryHub&am=${totalAmount}`, (error) => {
        if (error) console.error(error);
    });
});

// Reminders
function checkReminders() {
    if (Notification.permission !== 'granted') {
        Notification.requestPermission();
    }
    const creditors = db.exec("SELECT DISTINCT creditor FROM invoices WHERE creditor != 'N/A'");
    if (creditors.length) {
        creditors[0].values.forEach(([creditor]) => {
            setTimeout(() => {
                if (Notification.permission === 'granted') {
                    new Notification(`Reminder: Check payment status with ${creditor}`);
                }
            }, 5000); // 5-second delay for demo; adjust as needed
        });
    }
}

// Reports
document.getElementById('generateReport').addEventListener('click', () => {
    const inventory = db.exec("SELECT item, stock FROM inventory");
    if (inventory.length) {
        const labels = inventory[0].values.map(row => row[0]);
        const data = inventory[0].values.map(row => row[1]);

        if (chart) chart.destroy();
        chart = new Chart(document.getElementById('reportChart'), {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Stock Levels',
                    data: data,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                }]
            },
            options: { scales: { y: { beginAtZero: true } } }
        });

        // Export to PDF
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        doc.text('Stock Report', 10, 10);
        inventory[0].values.forEach((row, i) => {
            doc.text(`${row[0]}: ${row[1]}`, 10, 20 + i * 10);
        });
        doc.save('stock_report.pdf');
    }
});

// Business Loans (Mock Data)
function loadLoans() {
    const loanOptions = [
        { name: 'Growth Loan', amount: 100000, interest: '8%' },
        { name: 'Quick Loan', amount: 50000, interest: '10%' }
    ];
    const container = document.getElementById('loanOptions');
    loanOptions.forEach(loan => {
        const div = document.createElement('div');
        div.className = 'col-md-6';
        div.innerHTML = `
            <div class="card p-3 mb-3">
                <h5>${loan.name}</h5>
                <p>Amount: ₹${loan.amount} | Interest: ${loan.interest}</p>
            </div>
        `;
        container.appendChild(div);
    });
}

// Online Sync (Mock; requires backend)
function syncData() {
    if (navigator.onLine) {
        console.log('Syncing data...');
        // Example: fetch('/sync', { method: 'POST', body: JSON.stringify(db.exec("SELECT * FROM invoices")[0].values) });
    }
}

// Initialize
initDB().then(() => {
    updateTables();
    loadLoans();
    checkReminders();
    setInterval(syncData, 60000); // Check sync every minute
});